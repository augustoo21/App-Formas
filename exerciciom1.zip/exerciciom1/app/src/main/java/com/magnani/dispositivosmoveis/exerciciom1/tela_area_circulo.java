package com.magnani.dispositivosmoveis.exerciciom1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class tela_area_circulo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_area_circulo_);

        double resultado = this.getIntent().getDoubleExtra("valor",0);
        TextView texto = findViewById(R.id.label_area_circulo);
        texto.setText(Double.toString(resultado));
    }
}
